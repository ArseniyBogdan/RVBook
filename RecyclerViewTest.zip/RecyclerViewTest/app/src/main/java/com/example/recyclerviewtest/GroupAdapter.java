package com.example.recyclerviewtest;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.RecyclerView;

import com.example.recyclerviewtest.DB.DBManager;

import java.util.ArrayList;
import java.util.List;

public class GroupAdapter extends  RecyclerView.Adapter<GroupAdapter.NameGroupViewHolder>{ // создаём адаптер, который унаследован от адаптера RecyclerView и передаём ему значения вложенного класса NameGroupViewHolder

    private int numberGroups; // переменная для кол-ва элементов списка
    private ArrayList<String> nameList = new ArrayList<String>(); //создаём переменную для списка строк(названий)
    private Context contextMain;
    private MainActivity mainactivity;

    public GroupAdapter(int numberGroups){ //Функция для получения кол-ва элементов списка
        this.numberGroups = numberGroups;
    }

    @Override
    public NameGroupViewHolder onCreateViewHolder(ViewGroup parent, int viewType) { //ф-ия, которой на вход передаём ViewGroup(компонент-контейнер), который выступает в роли самого RecyclerView, следовательно все элементы будут поступать в него (создаём элемент списка)
        Context context = parent.getContext(); //получаем контекст RecyclerView
        int layoutIdForListItem = R.layout.group_list_element; // находим наш xml file для элемента списка

        LayoutInflater inflater = LayoutInflater.from(context); // создаём новое представление(ViewHolder)

        View view = inflater.inflate(layoutIdForListItem, parent, false); // передаём айди нашего xml файла (для того, чтобы метод inflate() понимал из чего мы будем создавать новый ViewHolder); какой элемент является родителем; False - хотим ли мы помещать ViewHolder сразу же после создания в родителя (нет конечно);

        NameGroupViewHolder viewHolder = new NameGroupViewHolder(view); // передаём наш элемент списка конструктору ф-ии NameGroupViewHolder, для того чтобы она обернула наши элементы в обёртку

        return viewHolder;
    }

    public void setListOfName(ArrayList<String> nameList){ //получаем список всех групп
        this.nameList.addAll(nameList);
    }

    @Override
    public void onBindViewHolder(NameGroupViewHolder holder, int position) { // метод для обновления данных при прокрутке списка
        holder.bind(nameList.get(position)); //передаём данные в функцию bind(), для устанавливки текста в TextView элемента списка //+
    }

    @Override
    public int getItemCount() { //функция возвращает кол-во элементов списка
        return numberGroups;
    }
    class NameGroupViewHolder extends RecyclerView.ViewHolder {

        TextView NameGroupView; //переменная для нашего Text View из layout group_list_element

        public NameGroupViewHolder(View itemView) { //что-то вроде графической обёртки для элемента списка
            super(itemView); //itemView - это элемент списка, который был сгенерирован из layout group_list_element

            NameGroupView = itemView.findViewById(R.id.groupName); // поместили в переменную ссылку на наш TextView (операция поиска по id очень затратная, следовательно её мы проводим один раз)

            itemView.setOnClickListener(new View.OnClickListener() { // обработчик нажатия на каждый из элементов списка
                @Override
                public void onClick(View v) {
                    int positionIndex = getAdapterPosition();
                    String Group_name = nameList.get(positionIndex);

//                    Class ButtonActivity = Button_Activity.class;
//
//                    Intent ButtonActivityIntent = new Intent(contextMain, ButtonActivity);
                    
                    Toast.makeText(contextMain, Group_name, Toast.LENGTH_LONG).show();
//                    mainactivity.StartActivityGroup();
                }
            });
        }

        void bind(String NameGroup){ // функция для установки текста в элеменнт списка, на вход подаётся название группы
            NameGroupView.setText(NameGroup); // кстанавливаем текст в наш TextView
        }
    }
    public void GetContextMain(Context context){ // получаем контекст
        contextMain = context;
    }
}

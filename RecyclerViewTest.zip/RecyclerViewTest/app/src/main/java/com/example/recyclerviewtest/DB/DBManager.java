package com.example.recyclerviewtest.DB;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
import java.util.List;

public class DBManager {
    private Context context;
    private DBHelper dbhelper;
    private SQLiteDatabase db;

    public DBManager(Context context) {
        this.context = context;
        dbhelper = new DBHelper(context);
    }

    public void openDB(){
        db = dbhelper.getWritableDatabase();
    }

    public void insertToGroups(String name){
        ContentValues cv = new ContentValues();
        cv.put(DBConstants.GROUP_NAME, name);
        db.insert(DBConstants.GROUPS_TABLE, null, cv);
        dbhelper.Add_Table(db, name); //Остановился тут
    }

    public ArrayList<String> GetAllGroups(){
        ArrayList<String> GroupList = new ArrayList<>();
        Cursor cursor = db.query(DBConstants.GROUPS_TABLE, null, null ,
                null ,null ,null ,null);

        while(cursor.moveToNext()){
            String name = cursor.getString(cursor.getColumnIndex(DBConstants.GROUP_NAME));
            GroupList.add(name);
        }

        cursor.close();
        return GroupList;
    }

    public long GetGroupsSize(){
        long rowCount  = DatabaseUtils.queryNumEntries(db, DBConstants.GROUPS_TABLE);
        return rowCount;
    }



    public void DBClose(){
        dbhelper.close();
    }

}

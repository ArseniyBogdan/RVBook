package com.example.recyclerviewtest;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class Button_Activity extends AppCompatActivity {


    private TextView sa_group;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.group_button_activity);

        sa_group = findViewById(R.id.SA_Group);
    }
}
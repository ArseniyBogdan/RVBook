package com.example.recyclerviewtest.DB;

public class DBConstants {
    public static final String GROUPS_TABLE = "Groups";
    public static final String _ID = "id";
    public static final String GROUP_NAME = "Group_name";
    public static final String DB_NAME = "database_for_diary";
    public static final String STUDENT_NAMES = "student_name";
    public static final int DB_VERSION = 1;

    public static final String GROUPS_STRUCTURE = "CREATE TABLE IF NOT EXISTS " +
            GROUPS_TABLE + " (" + _ID + " INTEGER PRIMARY KEY," + GROUP_NAME + " TEXT)";


    public static final String DROP_GROUPS_TABLE = "DROP TABLE IF EXISTS" + GROUPS_TABLE;
}

package com.example.recyclerviewtest;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.recyclerviewtest.DB.DBConstants;
import com.example.recyclerviewtest.DB.DBManager;
import com.google.android.material.snackbar.Snackbar;
import com.rengwuxian.materialedittext.MaterialEditText;

import java.util.ArrayList;
import java.util.List;
import java.util.jar.Attributes;

public class MainActivity extends AppCompatActivity {

    private DBManager dbManager;

    private RecyclerView GroupList;
    private GroupAdapter groupAdapter;

    private Button btnAlert;

    private ConstraintLayout root;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //this.deleteDatabase("database_for_diary"); //удаление базы данных


        dbManager = new DBManager(this);
        dbManager.openDB();

        GroupList = findViewById(R.id.rv_Groups); //нашли наш RecyclerView по айдишнику

        LinearLayoutManager layoutManager = new LinearLayoutManager(this); //задаём стиль отображения, как в LinearLayout
        GroupList.setLayoutManager(layoutManager); // передаём этот стиль отображения нашему RecyclerView

        groupAdapter = new GroupAdapter((int) dbManager.GetGroupsSize()); // вводим кол-воэлементов списка
        groupAdapter.setListOfName(dbManager.GetAllGroups()); //Передаём список строк адаптеру
        GroupList.setAdapter(groupAdapter);

        groupAdapter.GetContextMain(MainActivity.this); // передаём контекст groupAdapter

        btnAlert = (Button) findViewById(R.id.btn_Alert); // ищём кноку добавления по айди

        root = (ConstraintLayout) findViewById(R.id.root_element); // добавляем в переменную root данные о Constraint Layout с activity_main

        btnAlert.setOnClickListener(new View.OnClickListener() { // устанавливаем обработчик нажатий на кнопку добавления
            @Override
            public void onClick(View v) { //перегружаем метод onClick для этой кнопки
                AlertDialog.Builder a_builder = new AlertDialog.Builder(MainActivity.this); // привязываем строителя диалоговых окон к переменной

                LayoutInflater inflater = LayoutInflater.from(MainActivity.this); //создаём некое представление
                View window_for_creation = inflater.inflate(R.layout.window_for_creation, null); // передаём айди нашего xml файла (для того, чтобы метод inflate() понимал из чего мы будем создавать новое представление; null - нет родителя;
                a_builder.setView(window_for_creation); //устанавливаем получившийся вид в нашего строителя диалоговых окон

                final MaterialEditText NameField = window_for_creation.findViewById(R.id.creationField); //помещаем ссылку на текстовое окно нашей карточки(CardView) в переменную для дальнейшей работы с этим полем.

                a_builder.setCancelable(false) // добавляет возможность отменить диалоговое окно, но мы ставим на False т.к. в дальнейшем сами создадим кнопку закрытия диалогового окна
                        .setPositiveButton("Добавить", new DialogInterface.OnClickListener() { // создаём положительную кнопку с текстом "Добавить"
                            @Override
                            public void onClick(DialogInterface dialog, int which) { // Перегружаем метод onClick для этой кнопки
                                if(TextUtils.isEmpty(NameField.getText().toString())){ // проверка на отсутствие текста в Текстовом поле
                                    Snackbar.make(root, "Введите название группы", Snackbar.LENGTH_SHORT).show(); //Небольшое уведомление в нижней части экрана, в котором говорится, что пользователь не ввёл название группы
                                    return;
                                }
                                dbManager.insertToGroups(NameField.getText().toString()); // добавляем Введённый текст в список названий
                                groupAdapter = new GroupAdapter((int) dbManager.GetGroupsSize()); // Создаём новый адаптер с увеличившимся размером списка
                                groupAdapter.setListOfName(dbManager.GetAllGroups()); // передаём наш список в адаптер на обработку
                                GroupList.setAdapter(groupAdapter); // Устанавливаем на наш RecyclerView новый адаптер
                            }
                        })
                        .setNegativeButton("Отменить", new DialogInterface.OnClickListener() { // создаём негативную кнопку с текстом "Отменить"
                            @Override
                            public void onClick(DialogInterface dialog, int which) { //Перегружаем метод onClick для этой кнопки
                                dialog.cancel(); // закрываем диалоговое окно
                            }
                        });
                AlertDialog alert = a_builder.create(); // создаём диалоговое окно
                alert.setTitle("Вы хотите создать новую группу?"); // устанавливаем заголовок в диалоговом окне
                alert.show(); // показываем диалоговое окно
            }


        });

    }
    @Override
    protected void onDestroy(){
        super.onDestroy();
        dbManager.DBClose();
    }

    public void StartActivityGroup(){
        Context context = MainActivity.this;
        Class ButtonActivity = Button_Activity.class;
        Intent ButtonActivityIntent = new Intent(context, ButtonActivity);
        startActivity(ButtonActivityIntent);
    }

}